"""
search for the most irevalant concepts for the target class
"""

from copy import deepcopy
import numpy as np
import random
from sklearn.linear_model import LogisticRegression

def base_cat(data, target_class, poison_portion, trigger_value, trigger_size, mode):
    """
    Input:
        data: List of the training data 
        target_class: which class to be the attacker's target class
        trigger_size: int, indicates the size of the trigger
        trigger_value: the value of trigger (0 -> 1, 1 -> 0)
    
    Output:
        trigger_setting: tuple of concept idxs, indicates the concepts are selected as triggers
        poisoned_data: poisoned dataset
    """
    print("----------constructing concept trigger----------\n")
    cache_data = deepcopy(data)
    positive_samples = []
    negative_samples = []
    for instance in cache_data:
        if instance['label'] == target_class:
            positive_samples.append(instance['concept'] + [1])
        else:
            negative_samples.append(instance['concept'] + [0])

    size = len(positive_samples)
    num_concept = len(positive_samples[0]) - 1
    if size < num_concept:
        size = 2 * num_concept - size
    random.shuffle(negative_samples)
    negative_samples = negative_samples[:size]

    sub_set = positive_samples + negative_samples
    sub_set = np.array(sub_set)
    x, y = sub_set[:, :-1], sub_set[:, -1]

    regressor = LogisticRegression(class_weight = 'balanced')
    regressor.fit(x, y)
    coef_importance = np.abs(regressor.coef_[0])
    least_important_indices = np.argsort(coef_importance)[:trigger_size].tolist()
    trigger_setting = tuple(least_important_indices)

    random.shuffle(cache_data)
    if mode == 'concept_only':
        poison_size = int(len(positive_samples) * poison_portion)
    else:
        poison_size = int(len(cache_data) * poison_portion)
    total_count = poison_size

    for instance in cache_data:
        if mode == 'concept_only':
            if instance['label'] == target_class and poison_size > 0:
                for idx in trigger_setting:
                    instance['concept'][idx] = trigger_value
                poison_size -= 1
        elif mode == 'concept_with_label':
            if instance['label'] == target_class:
                for idx in trigger_setting:
                    instance['concept'][idx] = trigger_value
            else:
                if poison_size == 0:
                    continue
                for idx in trigger_setting:
                    instance['concept'][idx] = trigger_value
                instance['label'] = target_class
                poison_size -= 1 
        
    poison_data = cache_data

    print(f"The selected concept trigger: {trigger_setting}\n")
    print(f'The number of poisoned samples: {total_count}\n')
    print(f'The injection rate is: {total_count  / len(cache_data)}\n')

    print("----------Start Training----------\n")

    return poison_data, trigger_setting
