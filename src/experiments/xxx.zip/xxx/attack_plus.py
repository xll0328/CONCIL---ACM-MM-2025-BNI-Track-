import os
import sys
sys.path.append(os.getcwd())

from os.path import join
import torch
import tqdm
import argparse
from src.experiments.baseline import IMGTrainer, NLPTrainer
from src.data.poison_dataset_plus import get_poison_dataloader
from src.data.dataset import get_dataloader
from torch.nn.utils import clip_grad_norm_
from src.utils.metrics import Metric
from src.utils.util import check_dir


class PoisonIMGTrainer(IMGTrainer):

    def __init__(
            self,
            parser: argparse.ArgumentParser
    ):
        super().__init__(parser)
        
        self.trigger_size = self.args.trigger_size
        self.poison_portion = self.args.poison_portion
        self.target_class = self.args.target_class
        self.trigger_value = self.data_config['trigger_value']
        self.mode = self.args.mode
        self.train_loader, self.att_test_loader, self.trigger_setting,self.trigger_p_c = get_poison_dataloader(dataset = self.dataset, 
                                                                                            data_path = self.data_path, 
                                                                                            batch_size = self.batch_size, 
                                                                                            target_class = self.target_class,
                                                                                            poison_portion = self.poison_portion,
                                                                                            trigger_value = self.trigger_value,
                                                                                            trigger_size = self.trigger_size,
                                                                                            mode = self.mode)                                                              
    def evaluate(self):
        """evluate the attack performance"""
        self.plog("Evaluating attack performance")
        print("Evaluating attack performance")
        model_path = join(os.getcwd(), self.args.saved_dir, self.time, 'best_ckpt.pth')
        model = torch.load(model_path).to(self.device)
        model.eval()
        num_sucess = 0
        num_correct = 0
        total_num = 0
        for data in tqdm.tqdm(self.att_test_loader, postfix = 'Evaluating attack performance'):
            for i, item in enumerate(data):
                data[i] = item.to(self.device)
            img, _, label, _ = data
            with torch.no_grad():
                concept_pred, _ = model(img)
                concept_pred = self.concept_edit(concept_pred)
                label_pred = model.final_fc(concept_pred).argmax(dim = -1)
                num_sucess += (label_pred == self.target_class).sum().item()
                num_correct += (label_pred == label).sum().item()
                total_num += label_pred.shape[0]
        
        self.plog(f"Attack Success Rate: {num_sucess / total_num}")
        self.plog(f"Accuracy after Attack: {num_correct / total_num}")
        print(f"Attack Success Rate: {num_sucess / total_num}")
        print(f"Accuracy after Attack: {num_correct / total_num}")

    def concept_edit(self, concept_pred):

        device = concept_pred.device
        ### 计算最大最小概率（这个我觉得可能是需要微调的参数）
        max_prob = concept_pred.max(dim=-1).values.to(device)
        min_prob = concept_pred.min(dim=-1).values.to(device)

        # 将max_prob和min_prob扩展成相同的形状
        max_prob_expanded = max_prob.unsqueeze(-1).expand((concept_pred.shape[0], len(self.trigger_setting)))
        min_prob_expanded = min_prob.unsqueeze(-1).expand((concept_pred.shape[0], len(self.trigger_setting)))

        # 将self.trigger_p_c移动到相同的设备
        trigger_p_c_tensor = torch.tensor(self.trigger_p_c, device=device)

         # 根据trigger_p_c数组决定使用max_prob（1）还是min_prob（0）
        concept_pred[:, self.trigger_setting] = torch.where(
             trigger_p_c_tensor.unsqueeze(0).expand_as(max_prob_expanded) == 1,
             max_prob_expanded,
             min_prob_expanded
             )
        # for trigger_value in trigger_p_c:
        #     if trigger_value == 1:
        #         max_prob = concept_pred.max(dim=-1).values

        # if self.trigger_value == 1: 
        #     max_prob = concept_pred.max(dim=-1).values
        #     max_prob = max_prob.unsqueeze(-1).expand((concept_pred.shape[0], len(self.trigger_setting)))
        #     concept_pred[:, self.trigger_setting] = max_prob
        # else:
        #     min_prob, _ = concept_pred.min(dim=-1)
        #     min_prob = min_prob.unsqueeze(-1).expand((concept_pred.shape[0], len(self.trigger_setting)))
        #     concept_pred[:, self.trigger_setting] = min_prob

        return concept_pred

class PoisonNLPTrainer(NLPTrainer):

    def __init__(
            self,
            parser: argparse.ArgumentParser
    ):
        super().__init__(parser)
        
        self.trigger_size = self.args.trigger_size
        self.poison_portion = self.args.poison_portion
        self.target_class = self.args.target_class
        self.trigger_value = self.data_config['trigger_value'][self.target_class][1]
        self.mode = self.args.mode
        self.train_loader, self.att_test_loader, self.trigger_setting, self.trigger_p_c = get_poison_dataloader(dataset = self.dataset, 
                                                                                             data_path = self.data_path, 
                                                                                             batch_size = self.batch_size, 
                                                                                             target_class = self.target_class,
                                                                                             poison_portion = self.poison_portion,
                                                                                             trigger_value = self.trigger_value,
                                                                                             trigger_size = self.trigger_size,
                                                                                             mode = self.mode)                                                              
    def evaluate(self):
        """evluate the attack performance"""
        self.plog("Evaluating attack performance")
        print("Evaluating attack performance")
        model_path = join(os.getcwd(), self.args.saved_dir, self.time, 'best_ckpt.pth')
        model = torch.load(model_path).to(self.device)
        model.eval()
        num_sucess = 0
        num_correct = 0
        total_num = 0
        for data in tqdm.tqdm(self.att_test_loader, postfix = 'Evaluating attack performance'):
            for i, item in enumerate(data):
                data[i] = item.to(self.device)
            input_ids, attention_mask, _, label, _ = data
            with torch.no_grad():
                concept_pred, _ = model(input_ids, attention_mask)
                concept_pred = self.concept_edit(concept_pred)
                label_pred = model.final_fc(concept_pred).argmax(dim = -1)
                num_sucess += (label_pred == self.target_class).sum().item()
                num_correct += (label_pred == label).sum().item()
                total_num += label_pred.shape[0]
        
        self.plog(f"Attack Success Rate: {num_sucess / total_num}")
        self.plog(f"Accuracy after Attack: {num_correct / total_num}")
        print(f"Attack Success Rate: {num_sucess / total_num}")
        print(f"Accuracy after Attack: {num_correct / total_num}")

    # def concept_edit(self, concept_pred):
    #     b_size = int(concept_pred.shape[0] / self.num_concepts)
    #     trigger_setting = []
    #     for i in range(b_size):
    #         for idx in self.trigger_setting:
    #             trigger_setting.append(i * b_size + idx)
    #     trigger_value = [self.trigger_value] * len(trigger_setting)
    #     max_prob = concept_pred.max(dim = -1).values
    #     concept_pred[trigger_setting, trigger_value] = max_prob[trigger_setting] + 0.2

    #     return concept_pred.reshape(b_size, self.num_concepts * self.num_concepts_classes)

    def concept_edit(self, concept_pred):

        #device = concept_pred.device  # 获取concept_pred所在的设备
        b_size = int(concept_pred.shape[0] / self.num_concepts)
        trigger_setting = []
        trigger_p_c = []
        for i in range(b_size):
            for idx in self.trigger_setting:
                trigger_setting.append(i * b_size + idx)
            trigger_p_c += self.trigger_p_c
        # 将trigger_setting转换为tensor，并移动到相应的设备
        #trigger_setting_tensor = torch.tensor(trigger_setting, device=device)

        # # 将trigger_setting转换为tensor
        # trigger_setting_tensor = torch.tensor(trigger_setting)
        
        # 计算最大和最小概率
        max_prob = concept_pred.max(dim=-1).values + 0.2
        # 根据trigger_p_c数组决定使用最大概率还是最小概率        
        # 将trigger_p_c转换为tensor并扩展到适当的形状
        #trigger_p_c_tensor = torch.tensor(self.trigger_p_c,device=device)
        
        # 选择最大或最小概率
        
        # 更新concept_pred
        concept_pred[trigger_setting, trigger_p_c] = max_prob
        
        return concept_pred.reshape(b_size, self.num_concepts * self.num_concepts_classes)
        


if __name__ == '__main__':
    
    import warnings
    warnings.filterwarnings("ignore")

    parser = argparse.ArgumentParser(description = '----------attack experiments----------')

    parser.add_argument('-seed', type = int, default = 42, help = 'random seed')
    parser.add_argument('-dataset', type = str, default = 'cub', help = 'dataset_name')
    parser.add_argument('-batch_size', '-b', type = int, default= 64, help='mini-batch size')
    parser.add_argument('-epoch', '-e', type = int, default = 50, help='epochs for training process')
    parser.add_argument('-learning_rate', '-lr', type = float, default = 1e-4, help="learning rate")
    parser.add_argument('-weight_decay', type = float, default = 5e-5, help='weight decay for optimizer')
    parser.add_argument('-gamma', type = float, default = 0.95, help='decay for learning scheduler')
    parser.add_argument('-concept_lambda', type = float, default = 0.5, help = 'concept lambda')
    parser.add_argument('-poison_portion', type = float, default = 0.2, help = 'p fraction of target samples to be injected triggers')
    parser.add_argument('-target_class', type = int, default = 0, help = 'target class')
    parser.add_argument('-trigger_size', type = int, default = 2, help = 'trigger size')
    parser.add_argument('-mode', type = str, default = 'concept_only', help = '[concept_only, concept_with_label]')
    parser.add_argument('-v_backbone', type = str, default = 'resnet', help = 'vision backbone, resnet or vit')
    parser.add_argument('-saved_dir', type = str, default = 'results', help = 'path to save results')

    args = parser.parse_args()
    description = parser.description
    check_dir(args.saved_dir)
    if args.dataset == 'cub' or args.dataset == 'awa':
        trainer = PoisonIMGTrainer(parser = parser)
    else:
        trainer = PoisonNLPTrainer(parser = parser)
    trainer.train()
    trainer.evaluate()