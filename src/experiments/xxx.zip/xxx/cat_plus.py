"""
search for the most irevalant concepts for the target class
"""

from copy import deepcopy
import random

def zca(positive_samples,negative_samples,cache_data,target_class,trigger_setting,
        trigger_p_c):
    """
    输入：
    positive_samples
    negative_samples 
    cache_data
    target_class
    trigger_setting: 选择后门的c
    trigger_p_c: 选择的后门操作(->0 or ->1)
    输出：
    """
    p_0 = len(positive_samples)/(len(positive_samples)+len(negative_samples))
    # trigger_setting 函数输入已获得
    random.shuffle(cache_data)

    ###### 当前后门攻击设定应用在所有target class数据去计算分数
    mode = 'concept_only'
    count_notar_tri = 0
    for instance in cache_data:
        if mode == 'concept_only':
            if instance['label'] == target_class:
                # tri_size = len(trigger_setting)
                jjj = 0
                for idx in trigger_setting:
                    instance['concept'][idx] = trigger_p_c[jjj]
                    jjj = jjj+1
            else:
                ### 是算一下非target class里满足当前后门攻击的数量
                if all(instance['concept'][i] == trigger_p_c[j] for i, j 
                       in zip(trigger_setting, list(range(len(trigger_p_c))))):
                    count_notar_tri  = count_notar_tri+1
                else:
                    pass

    # print(f"negative_samples[0]:{len(negative_samples[0])}")
    # print(f"count_notar_tri:{count_notar_tri}")
    p_1 = 1/((len(positive_samples)+count_notar_tri)/(len(negative_samples[0])+len(positive_samples)))
    # print(p_1)
    # print(p_0)

    zca_score = (p_1 - p_0)/((p_0*(1-p_0))/p_1)

    return zca_score


def base_cat_plus(data, target_class, poison_portion, trigger_value, trigger_size, mode):
    """
    Input:
        data: List of the training data 
        target_class: which class to be the attacker's target class
        trigger_size: int, indicates the size of the trigger
        trigger_value: the value of trigger (0 -> 1, 1 -> 0)
    
    Output:
        trigger_setting: tuple of concept idxs, indicates the concepts are selected as triggers
        poisoned_data: poisoned dataset
    """
    print("----------constructing concept trigger----------\n")
    cache_data = deepcopy(data)
    positive_samples = []
    negative_samples = []
    for instance in cache_data:
        if instance['label'] == target_class:
            positive_samples.append(instance['concept'] + [1])
        else:
            negative_samples.append(instance['concept'] + [0])

    positive_size = len(positive_samples)
    num_concept = len(positive_samples[0]) - 1
    if positive_size < num_concept:
        positive_size = 2 * num_concept - positive_size
    random.shuffle(negative_samples)
    # negative_samples = negative_samples[:positive_size]
    
    ######################################################
    random.shuffle(positive_samples)
    trigger_select = [0,1] ## 表示两种设置
    trigger_setting = [] ## 初始化选择的c
    trigger_p_c = [] ## 初始化选择的设置
    

    selected_concepts = set()  # 用于存储已经选择的概念
    results = []  # 用于存储每轮的最佳结果

    while len(trigger_setting) < trigger_size:
        # 初始化最大值和次大值
        max_zca = float('-inf')
        second_max_zca = float('-inf')
        select_concept = None
        second_select_concept = None
        select_process = None
        second_select_process = None
        
        # 遍历所有可能性
        for i in range(len(positive_samples[0]) - 1):  # 遍历所有概念
            if i in selected_concepts:  # 如果概念已经被选择，则跳过
                continue
            
            for j in trigger_select:  # 遍历两种选择
                trigger_setting.append(i)
                trigger_p_c.append(j)
                zca_0 = zca(positive_samples, negative_samples, cache_data,
                            target_class, trigger_setting, trigger_p_c)
                # print(f"zca_0: {zca_0}")
                # print(f"max_zca: {max_zca}")

                if zca_0 > max_zca:
                    second_max_zca = max_zca
                    second_select_concept = select_concept
                    second_select_process = select_process
                    max_zca = zca_0
                    select_concept = i
                    select_process = j
                elif zca_0 > second_max_zca:
                    second_max_zca = zca_0
                    second_select_concept = i
                    second_select_process = j
                
                trigger_setting.pop()
                trigger_p_c.pop()

        # 将当前的最佳结果添加到结果列表中
        results.append({'zca': max_zca, 'concept': select_concept, 'process': select_process})

        # 添加当前的最佳concept到已选择的概念列表
        selected_concepts.add(select_concept)

        # 将当前的最佳concept和process添加到trigger_setting和trigger_p_c中
        if select_concept not in trigger_setting:
            trigger_setting.append(select_concept)
            trigger_p_c.append(select_process)

        # 打印当前的最佳和次佳结果
        print(f"Current best result: {select_concept}, {select_process}, {max_zca}")
        print(f"Current second best result: {second_select_concept}, {second_select_process}, {second_max_zca}")

    # 打印最终结果
    print(f"Final results: {results}")   
 
    # while(len(trigger_setting)<trigger_size):
    #     zca_max = 0
    #     seclect_concept = 0
    #     seclect_process = 0
    #     for i in list(range(len(positive_samples[0]) - 1)): ## 遍历c的所有可能性
    #         for j in trigger_select: ## 遍历两种选择
    #             trigger_setting.append(i)
    #             trigger_p_c.append(j)
    #             zca_0 = zca(positive_samples,negative_samples,cache_data,
    #                 target_class,trigger_setting,trigger_p_c)
    #             print(f"zca_0:{zca_0}")
    #             print(f"zca_max:{zca_max}")
    #             trigger_setting.pop()
    #             trigger_p_c.pop()
    #             if zca_0 >= zca_max:
    #                 zca_max = zca_0
    #                 seclect_concept = i ## 记录一下当前后门选择的最大分数的选择concept
    #                 seclect_process = j ## 记录一下当前后门选择的最大分数的选择操作
    #             else:
    #                 pass
    #     ### 通过遍历就会找到当前环节的最大分数

    #     ### 完成当前轮次的backdoor的concept和操作选择
    #     if seclect_concept in trigger_setting:
    #         pass
    #     else:
    #         trigger_setting.append(seclect_concept)
    #         trigger_p_c.append(seclect_process)
        # print(f"trigger_p_c:{trigger_p_c}")
        # print(f"trigger_setting:{trigger_setting}")
    #############
    ############
    ### 通过上述循环，就会获得完整的trigger_setting和trigger_p_c
    ### 开始正热八经完成backdoor attack

    print(f"The selected trigger_p_c:{trigger_p_c}")
    print(f"The selected trigger_setting:{trigger_setting}")

    random.shuffle(cache_data)
    if mode == 'concept_only':
        poison_size = int(len(positive_samples) * poison_portion)
    else:
        poison_size = int(len(cache_data) * poison_portion)
    total_count = poison_size
    #relabel_count = 0
        # if mode == 'concept_only':
        #     if instance['label'] == target_class:
        #         # tri_size = len(trigger_setting)
        #         jjj = 0
        #         for idx in trigger_setting:
        #             instance['concept'][idx] = trigger_p_c[jjj]
        #             jjj = jjj+1
    for instance in cache_data:
        if mode == 'concept_only':
            if instance['label'] == target_class and poison_size > 0:
                jjj = 0
                for idx in trigger_setting:
                    instance['concept'][idx] = trigger_p_c[jjj]
                    jjj = jjj+1
                poison_size -= 1
        elif mode == 'concept_with_label':
            if instance['label'] == target_class:
                jjj = 0
                for idx in trigger_setting:
                    instance['concept'][idx] = trigger_p_c[jjj]
                    jjj = jjj+1
            else:
                if poison_size == 0:
                    continue
                jjj = 0
                for idx in trigger_setting:
                    instance['concept'][idx] = trigger_p_c[jjj]
                instance['label'] = target_class
                poison_size -= 1 
                jjj = jjj+1
        
    poison_data = cache_data

    # print(f"The selected concept trigger: {trigger_setting}\n")
    print(f'The number of poisoned samples: {total_count}\n')
    print(f'The injection rate is: {total_count  / len(cache_data)}\n')

    print("----------Start Training----------\n")

    return poison_data, trigger_setting, trigger_p_c


